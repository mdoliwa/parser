class PageView < Struct.new(:page, :ip); end
